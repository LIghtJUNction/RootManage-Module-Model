go build
OR
gogogo -s ./gogogo.go -i