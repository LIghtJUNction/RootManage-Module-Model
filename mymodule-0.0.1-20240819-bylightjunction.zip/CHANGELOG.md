v0.0.0诞生了！
模块作者是lightjunction
模块名字是mymodule
模块id是id是MyModule
模块的作用是请点击actions，找到initial，运行这个工作流
此后的更新日志需要自己编辑CHANGGELOG.md！（记得把这一行删了）

