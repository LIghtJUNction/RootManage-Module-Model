from .fs import *

__doc__ = fs.__doc__
if hasattr(fs, "__all__"):
    __all__ = fs.__all__