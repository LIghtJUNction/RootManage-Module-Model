from .config import *

__doc__ = config.__doc__
if hasattr(config, "__all__"):
    __all__ = config.__all__